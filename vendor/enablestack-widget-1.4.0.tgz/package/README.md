# Enablestack Widget

The EnableUser accessibility widget — a floating menu with 29 tools (text sizing, contrast, reading guides, read-aloud, voice control, magnifier, reader view, virtual keyboard, dictionary), 4 one-click profiles, and UI in 35+ languages. It runs entirely in the browser inside a Shadow DOM, so it never clashes with your page styles.

**You set your brand color at install time, and the whole widget matches it** — the launcher button, menu accents, highlights and focus rings are all derived from one color. The default is the EnableUser brand purple, `#54467D`.

## Install

```bash
npm install enablestack-widget
```

During install you'll be asked for your brand color and a launcher icon:

```
🎨 Enter your brand color as a hex code (default #54467D):

♿ Choose a widget icon:
  1) Accessibility person (default)
  2) Wheelchair
  3) Active person
  4) Eye / vision
  Enter 1-4 (default 1):
```

Enter your values (or press Enter to keep the defaults). Both choices are baked into `dist/enablestack-widget.js`.

### Non-interactive installs (CI, Docker, `--yes`)

Prompts are skipped when there's no terminal. Provide the values up front instead:

```bash
ENABLESTACK_PRIMARY="#1E88E5" ENABLESTACK_ICON="wheelchair" npm install enablestack-widget
```

`ENABLESTACK_ICON` accepts `default`, `wheelchair`, `person`, or `eye`. Without them, the install falls back to `#54467D` + the default icon and never blocks.

### Change color / icon later

```bash
npx enablestack-widget-theme "#1E88E5" wheelchair
# color only (keeps default icon):
npx enablestack-widget-theme "#1E88E5"
# or run with no arguments to be prompted for both
npx enablestack-widget-theme
```

## Use

Serve the generated file and it auto-initializes on load:

```html
<script src="node_modules/enablestack-widget/dist/enablestack-widget.js"></script>
```

Or import it in a bundler:

```js
import 'enablestack-widget'; // resolves to dist/enablestack-widget.js
```

The launcher appears in the corner; clicking it opens the accessibility menu.

## Overriding at runtime

The baked-in color is applied only if the host page hasn't set one. To override per page — or to configure position, language, and features — set `ENABLESTACK_CONFIG` **before** the script loads:

```html
<script>
  window.ENABLESTACK_CONFIG = {
    colors: { primary: '#1E88E5' },   // exact hex; overrides the install-time color
    // theme: 'blue',                 // or a named preset: purple, blue, indigo, violet, teal, green, rose, orange, slate, dark
    icon: 'wheelchair',               // launcher icon: default, wheelchair, person, eye
    widgetPosition: { side: 'left' }, // 'left' or 'right'
    // language: 'en',                // force a language (default: auto-detect)
    accessibilityStatementUrl: ''     // optional footer link
  };
</script>
<script src="node_modules/enablestack-widget/dist/enablestack-widget.js"></script>
```

## Notes

- `widget.js` (source) and `dist/enablestack-widget.js` (themed build) ship in the package. Always serve the `dist/` file so your color is applied.
- Two optional tools make on-demand third-party requests: the Dictionary tool (`api.dictionaryapi.dev`) and the dyslexia font (`cdn.jsdelivr.net`). Nothing else leaves the browser.
- License: GPL-3.0-or-later. © enableuser — https://www.enableuser.com
