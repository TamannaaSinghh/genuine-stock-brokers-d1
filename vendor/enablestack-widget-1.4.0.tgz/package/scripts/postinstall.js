'use strict';

/**
 * Runs after `npm install enablestack-widget`.
 *
 * Asks the integrator for their brand hex color and a launcher icon, and bakes
 * both into the build so the widget matches their site out of the box.
 * Resolution order for each value:
 *   1. Env var: ENABLESTACK_PRIMARY / ENABLESTACK_ICON (great for CI)
 *   2. Interactive prompt (only when a TTY is attached and not in CI)
 *   3. Defaults: color #54467D, icon "default"
 *
 * A non-interactive install never blocks — it uses env vars or the defaults.
 */

const { applyTheme, isHex, normalizeHex, isIcon, ICONS, DEFAULT_PRIMARY, DEFAULT_ICON } = require('../lib/generate');

function finish(primary, icon, note) {
  const applied = applyTheme(primary, icon);
  console.log('\n\x1b[35m●\x1b[0m Enablestack widget themed — color \x1b[1m' + applied.primary + '\x1b[0m, icon \x1b[1m' + applied.icon + '\x1b[0m' + (note ? ' (' + note + ')' : ''));
  console.log('  Serve \x1b[1mnode_modules/enablestack-widget/dist/enablestack-widget.js\x1b[0m (or import the package).');
  console.log('  Change it later:  \x1b[1mnpx enablestack-widget-theme <hexcolor> [icon]\x1b[0m\n');
}

function envColor() {
  const v = process.env.ENABLESTACK_PRIMARY;
  return v && isHex(v) ? normalizeHex(v) : null;
}
function envIcon() {
  const v = process.env.ENABLESTACK_ICON;
  return v && isIcon(v) ? v : null;
}

function canPrompt() {
  return process.stdin.isTTY && process.stdout.isTTY && !process.env.CI && process.env.npm_config_yes !== 'true';
}

function askColor(rl, cb) {
  const ask = function (attemptsLeft) {
    rl.question('\n🎨 Enter your brand color as a hex code (default ' + DEFAULT_PRIMARY + '): ', function (answer) {
      answer = String(answer || '').trim();
      if (!answer) { cb(DEFAULT_PRIMARY); return; }
      if (isHex(answer)) { cb(normalizeHex(answer)); return; }
      if (attemptsLeft > 0) {
        console.log('  "' + answer + '" is not a valid hex color (e.g. #54467D). Try again.');
        ask(attemptsLeft - 1);
      } else {
        console.log('  Using default color.');
        cb(DEFAULT_PRIMARY);
      }
    });
  };
  ask(2);
}

function askIcon(rl, cb) {
  const menu = ICONS.map(function (ic, i) { return '  ' + (i + 1) + ') ' + ic.label; }).join('\n');
  const ask = function (attemptsLeft) {
    rl.question('\n♿ Choose a widget icon:\n' + menu + '\n  Enter 1-' + ICONS.length + ' (default 1): ', function (answer) {
      answer = String(answer || '').trim();
      if (!answer) { cb(DEFAULT_ICON); return; }
      const n = parseInt(answer, 10);
      if (n >= 1 && n <= ICONS.length) { cb(ICONS[n - 1].key); return; }
      if (isIcon(answer)) { cb(answer); return; }
      if (attemptsLeft > 0) {
        console.log('  Please enter a number between 1 and ' + ICONS.length + '.');
        ask(attemptsLeft - 1);
      } else {
        console.log('  Using default icon.');
        cb(DEFAULT_ICON);
      }
    });
  };
  ask(2);
}

function main() {
  const eColor = envColor();
  const eIcon = envIcon();

  // If both provided via env, or we can't prompt, skip interaction.
  if (!canPrompt()) {
    const note = (eColor || eIcon)
      ? 'from env vars / defaults'
      : 'non-interactive install; set ENABLESTACK_PRIMARY / ENABLESTACK_ICON or run npx enablestack-widget-theme <hex> [icon]';
    finish(eColor || DEFAULT_PRIMARY, eIcon || DEFAULT_ICON, note);
    return;
  }

  const readline = require('readline');
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

  const proceedColor = function (color) {
    if (eIcon) { rl.close(); finish(color, eIcon); return; }
    askIcon(rl, function (icon) { rl.close(); finish(color, icon); });
  };

  if (eColor) {
    proceedColor(eColor);
  } else {
    askColor(rl, proceedColor);
  }
}

try {
  main();
} catch (err) {
  // Never fail the install because of theming.
  console.warn('enablestack-widget: could not run setup (' + err.message + '). Using defaults.');
  try { applyTheme(DEFAULT_PRIMARY, DEFAULT_ICON); } catch (e) { /* ignore */ }
}
